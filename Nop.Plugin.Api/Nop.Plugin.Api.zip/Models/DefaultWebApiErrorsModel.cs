﻿namespace Nop.Plugin.Api.Models
{
    public class DefaultWebApiErrorsModel
    {
        public string Message { get; set; }

        public string MessageDetail { get; set; }
    }
}
